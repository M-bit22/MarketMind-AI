
import ipaddress
import logging
import socket
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator

logger = logging.getLogger("marketmind.retrieve")

MAX_RESPONSE_BYTES = 1_000_000
MAX_TEXT_CHARS = 20_000
REQUEST_TIMEOUT = (5, 15)


class RetrieveArgs(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    url: HttpUrl

    @field_validator("url")
    @classmethod
    def validate_public_url(cls, value: HttpUrl) -> HttpUrl:
        parsed = urlparse(str(value))

        if parsed.scheme != "https":
            raise ValueError("Only HTTPS URLs are allowed.")

        if parsed.username or parsed.password:
            raise ValueError("URLs containing credentials are not allowed.")

        hostname = parsed.hostname
        if not hostname:
            raise ValueError("URL must contain a hostname.")

        # Reject local names and literal IPs that are not public.
        if hostname.lower() in {"localhost", "localhost.localdomain"}:
            raise ValueError("Local addresses are not allowed.")

        try:
            ip = ipaddress.ip_address(hostname)
            if not ip.is_global:
                raise ValueError("Non-public IP addresses are not allowed.")
        except ValueError as error:
            if "not allowed" in str(error):
                raise

        # Resolve hostnames and reject private or reserved destinations.
        try:
            addresses = socket.getaddrinfo(
                hostname, 443, type=socket.SOCK_STREAM
            )
        except socket.gaierror as error:
            raise ValueError("Hostname could not be resolved.") from error

        for address in addresses:
            ip = ipaddress.ip_address(address[4][0])
            if not ip.is_global:
                raise ValueError(
                    "URL resolves to a non-public network address."
                )

        return value


def retrieve_document(url: str) -> dict:
    args = RetrieveArgs(url=url)

    headers = {
        "User-Agent": "MarketMindAI/1.0 (research document retrieval)"
    }

    try:
        with requests.get(
            str(args.url),
            headers=headers,
            timeout=REQUEST_TIMEOUT,
            stream=True,
            allow_redirects=False,
        ) as response:
            if response.status_code in {301, 302, 303, 307, 308}:
                raise RuntimeError(
                    "The page redirected. Submit the destination URL directly."
                )

            response.raise_for_status()

            content_type = response.headers.get("Content-Type", "")
            if "text/html" not in content_type.lower():
                raise ValueError("The URL did not return an HTML document.")

            declared_size = response.headers.get("Content-Length")
            if declared_size and int(declared_size) > MAX_RESPONSE_BYTES:
                raise ValueError("The webpage exceeds the size limit.")

            chunks = []
            total_bytes = 0

            for chunk in response.iter_content(chunk_size=8192):
                if not chunk:
                    continue

                total_bytes += len(chunk)
                if total_bytes > MAX_RESPONSE_BYTES:
                    raise ValueError("The webpage exceeds the size limit.")

                chunks.append(chunk)

            html = b"".join(chunks)

        soup = BeautifulSoup(html, "html.parser")

        # Remove elements that are not useful as research text.
        for element in soup(
            ["script", "style", "nav", "footer", "header", "noscript"]
        ):
            element.decompose()

        title = soup.title.get_text(" ", strip=True) if soup.title else ""
        text = soup.get_text(" ", strip=True)
        text = " ".join(text.split())[:MAX_TEXT_CHARS]

        if not text:
            raise ValueError("No readable text was found on the webpage.")

        result = {
            "url": str(args.url),
            "title": title,
            "text": text,
            "character_count": len(text),
            "truncated": len(text) == MAX_TEXT_CHARS,
            "source_kind": "retrieved_document",
        }

        logger.info(
            "Document retrieved; host=%s characters=%s",
            urlparse(str(args.url)).hostname,
            len(text),
        )

        return result

    except (requests.RequestException, OSError) as error:
        logger.warning(
            "Document retrieval failed; error_type=%s",
            type(error).__name__,
        )
        raise RuntimeError(
            "Document retrieval failed. Check the URL or retry later."
        ) from error
